import { Context, Schema } from 'koishi';
import { Config as InterludeConfig, InterludeService } from './service';
declare module 'koishi' {
    interface Context {
        cev: InterludeService;
    }
}
export declare const name = "hds-interlude-cev";
export declare const version = "1.0.1-rc12-cev.4";
export declare const inject: {
    required: string[];
    optional: string[];
};
export declare const Config: Schema<InterludeConfig>;
export declare function apply(ctx: Context, config: InterludeConfig): void;
export * from './narrator';
export * from './service';
export * from './types';
