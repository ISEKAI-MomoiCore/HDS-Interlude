/**
 * 路线图 #2 用户侧人格档案演化 + #3 环境实感注入（天气）
 * 轻量实现：复用 ParticipantState（profileOverlay）与独立 weather 字段。
 */
import { Context } from 'koishi';
export interface UserProfilePatchDraft {
    /** 目标参与者 personId；压缩时只知道一个上下文窗口内的主要用户。 */
    personId: string;
    /** 累进式的理解深化（≤500 字），追加而非替换。 */
    understanding: string;
    evidence: string;
    confidence: number;
}
/** 压缩提示词追加指令（拼在 compactionPrompt 尾部）。 */
export declare const USER_PROFILE_PATCH_INSTRUCTION = "userProfiles (optional): when the supplied entries reveal a durable shift in how the protagonist understands a user (their mood pattern, life situation, values, or communication habits), include userProfiles: [{\"personId\":\"the participant personId\",\"understanding\":\"one concise sentence in Chinese, at most 120 characters, describing the new understanding\",\"evidence\":\"brief factual basis from the entries\",\"confidence\":0.0}]. Only when something genuinely new and lasting emerges; omit entirely for routine exchanges.";
/** 应用 patch：追加到 participant.state.profileOverlay（非替换）。 */
export declare function applyUserProfilePatch(currentOverlay: string | undefined, patch: UserProfilePatchDraft): string;
export interface WeatherSnapshot {
    /** 城市显示名（Console 配置的原文） */
    city: string;
    /** 天气描述（中文，如"多云"） */
    condition: string;
    /** 温度 °C */
    temperature: number;
    /** 体感温度 °C */
    feelsLike: number;
    /** 湿度 % */
    humidity: number;
    /** 风速 km/h */
    windSpeed: number;
    /** 本地日期时间（故事时区） */
    localTime: string;
}
export declare function fetchWeather(ctx: Context, city: string, timezone: string): Promise<WeatherSnapshot | undefined>;
/** 注入 payload 的 weather 字段（纯数据，不 teach 模型——让主角自然感知）。 */
export declare function weatherPromptField(snapshot: WeatherSnapshot): Record<string, unknown>;
