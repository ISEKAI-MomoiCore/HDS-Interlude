import { Context } from 'koishi';
import { InterludeArc, InterludeParticipant, InterludeScene, InterludeStory, NarrativeFact, NarrativeIntent, NarrativeMemory, OverlaySnapshot, SchedulePreplanRecord, ScriptEntry, StatePatchProposal, StickerAsset, WebObservation } from './types';
import type { WorkRow } from './works';
declare module 'koishi' {
    interface Tables {
        cev_work: WorkRow;
        cev_interlude_story: InterludeStory;
        cev_interlude_participant: InterludeParticipant;
        cev_interlude_script_entry: ScriptEntry;
        cev_interlude_memory: NarrativeMemory;
        cev_interlude_intent: NarrativeIntent;
        cev_interlude_scene: InterludeScene;
        cev_interlude_arc: InterludeArc;
        cev_interlude_fact: NarrativeFact;
        cev_interlude_state_patch: StatePatchProposal;
        cev_interlude_overlay_snapshot: OverlaySnapshot;
        cev_interlude_sticker: StickerAsset;
        cev_interlude_web_observation: WebObservation;
        cev_interlude_schedule_preplan: SchedulePreplanRecord;
    }
}
export declare function registerTables(ctx: Context): void;
