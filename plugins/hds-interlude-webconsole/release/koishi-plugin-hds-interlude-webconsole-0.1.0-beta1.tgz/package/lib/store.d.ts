type Row = Record<string, any>;
export declare function parseJson(value: unknown, fallback?: unknown): any;
export declare class SqliteStore {
    private db;
    constructor(dbFile: string);
    close(): void;
    /** A read transaction makes each JSON response internally consistent. */
    snapshot<T>(read: () => T): T;
    private hasTable;
    missingTables(): string[];
    /** Freezes the latest-story choice once per HTTP request. */
    resolveStoryId(id?: string): string | null;
    stories(): {
        id: import("node:sqlite").SQLOutputValue;
        status: import("node:sqlite").SQLOutputValue;
        cursorAt: import("node:sqlite").SQLOutputValue;
        updatedAt: import("node:sqlite").SQLOutputValue;
        timezone: any;
    }[];
    storySummary(id?: string | null): {
        id: string;
        status: any;
        cursorAt: any;
        updatedAt: any;
        setting: any;
        entryCount: number;
        automation: import("koishi-plugin-hds-interlude").StoryAutomationState;
        urge: unknown;
        alter: import("koishi-plugin-hds-interlude").AlterSystemState;
        agencyWindow: import("koishi-plugin-hds-interlude").AgencyWindowState;
        settingOverlay: import("koishi-plugin-hds-interlude").StorySettingOverlay;
    };
    private rows;
    scriptEntries(opts: {
        before?: number;
        after?: number;
        limit: number;
        kind?: string;
        participantId?: string;
    }, id?: string | null): {
        rows: Row[];
        hasMore: boolean;
        total: number;
    };
    scenes(id: string | null): Row[];
    arc(id: string | null): Row;
    overlayPatches(id: string | null): Row[];
    overlaySnapshots(id: string | null): Row[];
    facts(opts: {
        scope?: string;
        limit: number;
    }, id: string | null): Row[];
    intents(opts: {
        status?: string;
        limit: number;
    }, id: string | null): Row[];
    memories(limit: number, id: string | null): Row[];
    participants(id: string | null): Row[];
    preplan(id: string | null): Row;
    longArcGuidance(id: string | null): Row[];
    /** SQLite data_version catches changes to ANY table committed by other connections. */
    revision(): number;
}
export type WebconsoleStore = SqliteStore;
export {};
