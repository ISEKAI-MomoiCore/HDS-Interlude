export interface LogLine {
    seq: number;
    time: string;
    level: string;
    name: string;
    message: string;
}
export declare class LogRing {
    readonly session: `${string}-${string}-${string}-${string}-${string}`;
    private buffer;
    private seq;
    private capacity;
    constructor(capacity: number);
    push(level: string, name: string, message: string, time?: string): void;
    get cursor(): number;
    since(seq: number, level?: string, name?: string): LogLine[];
    latest(count?: number, level?: string, name?: string): LogLine[];
    read(opts: {
        since?: number;
        session?: string;
        limit?: number;
        level?: string;
        name?: string;
    }): {
        session: `${string}-${string}-${string}-${string}-${string}`;
        cursor: number;
        reset: boolean;
        dropped: boolean;
        lines: LogLine[];
    };
}
/** Dedicated reggol transport; never overrides global console methods or other transports. */
export declare function attachLogCapture(ring: LogRing): () => void;
