import type { IncomingMessage, ServerResponse } from 'node:http';
import type { WebconsoleStore } from './store';
import type { LogRing } from './logring';
export interface ApiContext {
    req: IncomingMessage;
    res: ServerResponse;
    path: string;
    search: URLSearchParams;
    store?: WebconsoleStore;
    ring?: LogRing;
    json: (res: ServerResponse, code: number, data: unknown) => void;
    sseClients: Set<ServerResponse>;
    pollSeconds: number;
    session?: string;
    autoRefresh?: boolean;
    integration?: {
        service: string;
        version: string;
    };
}
export declare class ApiInputError extends Error {
}
export declare function num(value: string | null): number | undefined;
export declare function handleApi(ctx: ApiContext): void;
