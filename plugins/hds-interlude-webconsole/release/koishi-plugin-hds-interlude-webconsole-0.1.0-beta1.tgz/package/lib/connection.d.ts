/** Select the driver bound to HDSI's table, not an arbitrary database instance. */
export declare function resolveInterludeDatabase(baseDir: string, driver: unknown, configured?: string): string;
