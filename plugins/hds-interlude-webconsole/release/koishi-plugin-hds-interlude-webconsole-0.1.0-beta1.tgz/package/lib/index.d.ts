import { Context, Schema } from 'koishi';
export { MIME } from './server';
export declare const name = "hds-interlude-webconsole";
export declare const inject: {
    readonly required: readonly ["database", "interlude"];
};
export interface WebconsoleConfig {
    enabled: boolean;
    port: number;
    host: string;
    token: string;
    pollSeconds: number;
    logBuffer: number;
    databasePath?: string;
    autoRefresh?: boolean;
}
export declare const Config: Schema<Schemastery.ObjectS<{
    enabled: Schema<boolean, boolean>;
    host: Schema<"127.0.0.1" | "localhost" | "::1", "127.0.0.1" | "localhost" | "::1">;
    port: Schema<number, number>;
    token: Schema<string, string>;
}> | Schemastery.ObjectS<{
    databasePath: Schema<string, string>;
}> | Schemastery.ObjectS<{
    autoRefresh: Schema<boolean, boolean>;
    pollSeconds: Schema<number, number>;
    logBuffer: Schema<number, number>;
}>, {
    enabled: boolean;
    host: "127.0.0.1" | "localhost" | "::1";
    port: number;
    token: string;
} & import("cosmokit").Dict & {
    databasePath: string;
} & {
    autoRefresh: boolean;
    pollSeconds: number;
    logBuffer: number;
}>;
export declare function apply(ctx: Context, config: WebconsoleConfig): void;
