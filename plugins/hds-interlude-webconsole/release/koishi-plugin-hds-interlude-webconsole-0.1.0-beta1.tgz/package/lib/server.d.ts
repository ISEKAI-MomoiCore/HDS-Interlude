import { type ServerResponse } from 'node:http';
import type { WebconsoleStore } from './store';
import type { LogRing } from './logring';
export declare const MIME: Record<string, string>;
export declare function isLoopback(host: string): boolean;
export interface ServerOptions {
    publicRoot: string;
    token: string;
    pollSeconds: number;
    store?: WebconsoleStore;
    ring?: LogRing;
    autoRefresh?: boolean;
    integration?: {
        service: string;
        version: string;
    };
    onError?: (error: unknown) => void;
    onRequestError?: (error: unknown) => void;
}
export declare function createWebServer(options: ServerOptions): {
    server: import("http").Server<typeof import("http").IncomingMessage, typeof ServerResponse>;
    stopStreams(): void;
};
