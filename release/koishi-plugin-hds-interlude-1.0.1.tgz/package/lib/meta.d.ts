export declare const HDS_INTERLUDE_VERSION = "1.0.1";
